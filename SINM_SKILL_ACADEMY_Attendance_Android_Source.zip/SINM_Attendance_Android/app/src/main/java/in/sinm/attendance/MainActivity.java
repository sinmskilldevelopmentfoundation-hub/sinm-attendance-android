package in.sinm.attendance;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import com.google.android.gms.mlkit.barcode.*;
import com.google.android.gms.tasks.Task;
import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;
import android.provider.MediaStore;
import android.content.ContentValues;

public class MainActivity extends Activity {
    final int BLUE=Color.rgb(16,42,99), GOLD=Color.rgb(212,175,55);
    DB db; String role=""; LinearLayout root, body; TextView heading;
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); showLogin();}
    TextView txt(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.DKGRAY);t.setPadding(8,8,8,8);return t;}
    Button btn(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));b.setOnClickListener(v->r.run());return b;}
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);return e;}
    void shell(String title){root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(0xFFF5F7FC);
        heading=txt("SINM SKILL ACADEMY\n"+title,20);heading.setTextColor(Color.WHITE);heading.setBackgroundColor(BLUE);heading.setGravity(17);root.addView(heading,new LinearLayout.LayoutParams(-1,-2));
        ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setPadding(16,12,16,24);body.setOrientation(1);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);}
    void showLogin(){shell("STUDENT ATTENDANCE"); EditText u=field("Username (admin / teacher)"),p=field("Password");p.setInputType(129);body.addView(txt("Welcome",22));body.addView(u);body.addView(p);
        body.addView(btn("LOGIN",()->{String a=u.getText().toString().trim(),b=p.getText().toString();
            if((a.equals("admin")&&b.equals("admin123"))||(a.equals("teacher")&&b.equals("teacher123"))){role=a;home();}
            else new AlertDialog.Builder(this).setMessage("Invalid login details").setPositiveButton("OK",null).show();}));
        body.addView(txt("Demo login: admin / admin123\nTeacher login: teacher / teacher123\nChange these credentials before real use.",14));}
    void home(){shell("DASHBOARD"); Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM students",null);c.moveToFirst();int n=c.getInt(0);c.close();
        body.addView(txt("Signed in as: "+role.toUpperCase(),16));body.addView(txt("Registered students: "+n,19));
        body.addView(btn("Register Student",()->addStudent()));
        body.addView(btn("Student List / QR Cards",()->students()));
        body.addView(btn("Mark Manual Attendance",()->manual()));
        body.addView(btn("Scan Student QR",()->scan()));
        body.addView(btn("Attendance Report / Export CSV",()->reports()));
        body.addView(btn("Logout",()->showLogin()));}
    void addStudent(){shell("REGISTER STUDENT");EditText name=field("Student full name"),id=field("Student ID / Roll number"),course=field("Course / Class"),phone=field("Mobile number");
        body.addView(name);body.addView(id);body.addView(course);body.addView(phone);
        body.addView(btn("SAVE STUDENT",()->{if(name.length()==0||id.length()==0){toast("Name and Student ID are required");return;}
            try{ContentValues v=new ContentValues();v.put("sid",id.getText().toString().trim());v.put("name",name.getText().toString().trim());v.put("course",course.getText().toString());v.put("phone",phone.getText().toString());
                db.getWritableDatabase().insertOrThrow("students",null,v);toast("Student saved");students();}catch(Exception e){toast("Student ID already exists");}}));
        body.addView(btn("Back",()->home()));}
    void students(){shell("STUDENT LIST");Cursor c=db.getReadableDatabase().rawQuery("SELECT sid,name,course,phone FROM students ORDER BY name",null);
        if(c.getCount()==0)body.addView(txt("No students registered yet.",16));
        while(c.moveToNext()){String id=c.getString(0),name=c.getString(1),course=c.getString(2),phone=c.getString(3);
            body.addView(txt(name+"  ("+id+")\n"+course+" • "+phone,16));
            body.addView(btn("Generate QR ID",()->qr(id,name,course)));
            body.addView(btn("Mark Present Today",()->mark(id,"Present","Manual")));}
        c.close();body.addView(btn("Add Student",()->addStudent()));body.addView(btn("Back",()->home()));}
    void qr(String id,String name,String course){try{BitMatrix m=new MultiFormatWriter().encode(id,BarcodeFormat.QR_CODE,700,700);Bitmap bm=Bitmap.createBitmap(700,700,Bitmap.Config.RGB_565);
        for(int x=0;x<700;x++)for(int y=0;y<700;y++)bm.setPixel(x,y,m.get(x,y)?Color.BLACK:Color.WHITE);
        shell("STUDENT QR ID");ImageView iv=new ImageView(this);iv.setImageBitmap(bm);iv.setAdjustViewBounds(true);body.addView(txt("SINM SKILL ACADEMY\n"+name+"\nID: "+id+"\n"+course,18));body.addView(iv,new LinearLayout.LayoutParams(-1,650));body.addView(btn("Back",()->students()));
    }catch(Exception e){toast("Could not create QR");}}
    void manual(){shell("MANUAL ATTENDANCE");EditText id=field("Enter Student ID");body.addView(id);
        for(String s:new String[]{"Present","Absent","Late","Leave"})body.addView(btn(s,()->{if(id.length()==0){toast("Enter student ID");return;}mark(id.getText().toString().trim(),s,"Manual");}));
        body.addView(btn("Back",()->home()));}
    void mark(String id,String status,String source){Cursor c=db.getReadableDatabase().rawQuery("SELECT name FROM students WHERE sid=?",new String[]{id});if(!c.moveToFirst()){c.close();toast("Student ID not found");return;}String name=c.getString(0);c.close();
        String date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        ContentValues v=new ContentValues();v.put("sid",id);v.put("date",date);v.put("status",status);v.put("source",source);
        db.getWritableDatabase().delete("attendance","sid=? AND date=?",new String[]{id,date});db.getWritableDatabase().insert("attendance",null,v);
        toast(name+": "+status+" saved");}
    void scan(){GmsBarcodeScanner scanner=GmsBarcodeScanning.getClient(this);scanner.startScan().addOnSuccessListener(barcode->{String id=barcode.getRawValue();if(id!=null){mark(id,"Present","QR");home();}}).addOnFailureListener(e->toast("QR scan failed: "+e.getMessage()));}
    void reports(){shell("ATTENDANCE REPORT");EditText date=field("Date YYYY-MM-DD (blank = today)");date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));body.addView(date);
        body.addView(btn("VIEW REPORT",()->showReport(date.getText().toString().trim())));
        body.addView(btn("EXPORT CSV",()->exportCsv(date.getText().toString().trim())));
        body.addView(btn("Back",()->home()));}
    void showReport(String date){Cursor c=db.getReadableDatabase().rawQuery("SELECT s.sid,s.name,s.course,IFNULL(a.status,'Not Marked') FROM students s LEFT JOIN attendance a ON s.sid=a.sid AND a.date=? ORDER BY s.name",new String[]{date});
        StringBuilder out=new StringBuilder("Date: "+date+"\n\n");while(c.moveToNext())out.append(c.getString(1)).append(" (").append(c.getString(0)).append(") - ").append(c.getString(3)).append("\n");c.close();
        new AlertDialog.Builder(this).setTitle("Attendance").setMessage(out.toString()).setPositiveButton("OK",null).show();}
    void exportCsv(String date){try{Cursor c=db.getReadableDatabase().rawQuery("SELECT s.sid,s.name,s.course,IFNULL(a.status,'Not Marked'),IFNULL(a.source,'') FROM students s LEFT JOIN attendance a ON s.sid=a.sid AND a.date=? ORDER BY s.name",new String[]{date});
        StringBuilder csv=new StringBuilder("Student ID,Name,Course,Status,Source,Date\n");while(c.moveToNext())csv.append(q(c.getString(0))).append(",").append(q(c.getString(1))).append(",").append(q(c.getString(2))).append(",").append(q(c.getString(3))).append(",").append(q(c.getString(4))).append(",").append(date).append("\n");c.close();
        ContentValues cv=new ContentValues();cv.put(MediaStore.Downloads.DISPLAY_NAME,"SINM_Attendance_"+date+".csv");cv.put(MediaStore.Downloads.MIME_TYPE,"text/csv");cv.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);
        android.net.Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);OutputStream os=getContentResolver().openOutputStream(uri);os.write(csv.toString().getBytes("UTF-8"));os.close();toast("CSV saved in Downloads");
    }catch(Exception e){toast("Export failed: "+e.getMessage());}}
    String q(String s){if(s==null)s="";return "\""+s.replace("\"","\"\"")+"\"";}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"sinm_attendance.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE students(sid TEXT PRIMARY KEY,name TEXT NOT NULL,course TEXT,phone TEXT)");
            d.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,sid TEXT NOT NULL,date TEXT NOT NULL,status TEXT NOT NULL,source TEXT,UNIQUE(sid,date))");}
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
    }
}
