# SINM SKILL ACADEMY – Student Attendance Android App

Native Android Java project. Build it from a phone using GitHub Actions (no Android Studio needed).

## Included
- Admin and Teacher demo sign-in
- Student registration and list
- QR code generation for student IDs
- QR scanning with Google Code Scanner
- Manual Present / Absent / Late / Leave attendance
- Daily report and CSV export
- Royal Blue & Gold theme
- GitHub Actions workflow to compile a debug APK in the cloud

## Demo credentials
- Admin: `admin` / `admin123`
- Teacher: `teacher` / `teacher123`

Change these demo credentials before real deployment. This initial version stores data locally on one device; it does not synchronize attendance between phones.

## Build the APK using only your Android phone
1. Create a free account at https://github.com/ and sign in using Chrome.
2. Create a **new public repository** named `sinm-attendance-android` (public repositories allow GitHub Actions to run with the free plan's public-repository allowance).
3. In the new repository choose **Add file → Upload files** and upload this ZIP file itself. Commit the upload to the `main` branch.
4. Choose **Add file → Create new file**. In the filename field enter `.github/workflows/build-apk.yml`.
5. Copy the contents of the included file `.github/workflows/build-apk.yml` into the editor and commit it to `main`.
6. Open the repository's **Actions** tab. Select **Build SINM Attendance APK** and press **Run workflow** if it has not started automatically.
7. Wait for the workflow to finish successfully. Open the completed run, scroll to **Artifacts**, and download `SINM-SKILL-ACADEMY-Attendance-APK`.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Tap it to install. If Android asks, allow Chrome or Files to **Install unknown apps** for this installation, then continue.

## Build details
- Application ID: `in.sinm.attendance`
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- Version: 1.0
- Build: Gradle 8.9, Android Gradle Plugin 8.7.3, JDK 17

## Important
The cloud workflow compiles the debug APK; it is not a Play Store release. Google Code Scanner may need Google Play services and internet access for its first module download. Keep the GitHub repository private if you do not want the source code publicly visible; GitHub plan limits for private Actions usage may apply.
